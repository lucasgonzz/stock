<?php $__env->startSection('content'); ?>
<div class="row justify-content-center m-t-30">
    <div class="col col-lg-4">
        <?php if(session('errorLogin')): ?>
            <div class="alert alert-danger">
                <p><?php echo e(session('errorLogin')); ?></p>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h1 class="h3">Ingreso</h1>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">Usuario</label>
                        <input type="text" name="name" id="name" placeholder="Nombre de usuario" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <input type="password" name="password" id="password" placeholder="Contraseña" class="form-control">
                    </div>
                    <button class="btn btn-primary btn-lg btn-block">Ingresar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\negocio\resources\views/auth/login.blade.php ENDPATH**/ ?>