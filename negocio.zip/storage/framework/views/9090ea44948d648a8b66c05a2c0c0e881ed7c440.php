<ul class="nav nav-pills">
    <li class="nav-item">
        <a class="nav-link <?php echo e(active('resumen-ventas-hoy')); ?>" href="<?php echo e(route('resumen-ventas-hoy')); ?>">Ventas de hoy</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(active('resumen-ventas-desde-una-fecha')); ?>" href="<?php echo e(route('resumen-ventas-desde-una-fecha')); ?>">Desde una fecha</a>
    </li>
</ul><?php /**PATH C:\wamp64\www\negocio\resources\views/includes/resumen-ventas-nav.blade.php ENDPATH**/ ?>