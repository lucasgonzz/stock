<?php $__env->startSection('content'); ?>
	<div id="resumen-ventas">
		<div class="row justify-content-center m-t-20 m-b-20">
			<div class="col col-lg-8">
				<?php echo $__env->make('includes.resumen-ventas-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
		</div>
		<div class="row justify-content-center">
			<div class="col col-lg-8">
				<ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist">
					<li class="nav-item m-l-0">
						<a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#hoy" role="tab" aria-controls="pills-home" aria-selected="true" @click="getSales">Todas</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#hoy" role="tab" aria-controls="pills-profile" aria-selected="false" @click="getSalesMorning">De mañana</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#hoy" role="tab" aria-controls="pills-contact" aria-selected="false" @click="getSalesAfternoon">De tarde</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#desde-una-fecha" role="tab" aria-controls="pills-contact" aria-selected="false" @click="getSalesAfternoon">Desde una fecha</a>
					</li>
				</ul>
			</div>
		</div>
		<?php echo $__env->make('includes.resumen-ventas-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- <hr style="background-color: #A8A8A8"> -->
		<?php echo $__env->make('includes.resumen-ventas-show-sales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>		
		<?php echo $__env->make('modals.lastSales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	new Vue({
	el: "#resumen-ventas",
	created: function(){
		this.getSales();
	},
	data: {
		sales: [],
		sale: {},
		article: {},
		mostrar: 'ventas-hoy',
		total: 0,
		lastSales: [],
		mostrar: 0,
		ventas_cont: 0,
	},
	methods: {
		deleteSale: function(sale){
			axios.delete('sales/' + sale.id)
			.then( response => {
				this.getSales();
				toastr.success('Se elimino la venta');
			})
			.catch( error => {
				console.log(error.response);
			})
		},
		showLastSales: function(articulo){
			this.article = articulo;
			this.lastSales = articulo.sales;
			$('#last-sales').modal('show');
		},
		getSales: function(){
			axios.get('sales/today')
			.then( response => { 
				this.sales = response.data;
				this.total = 0;
				this.ventas_cont = 0;
				for(let i in this.sales){
					this.sales[i].total = 0;
					for(let j in this.sales[i].articles){
						this.total += this.sales[i].articles[j].price;
						this.sales[i].total += this.sales[i].articles[j].price;
						this.ventas_cont ++;
					}
				}
			})
			.catch( error => {
				console.log(error.response);
			})
		},
		getSalesMorning: function(){
			axios.get('sales/today/morning')
			.then( response => {
				this.sales = response.data;
				this.total = 0;
				this.ventas_cont = 0;
				for(let i in this.sales){
					this.sales[i].total = 0;
					for(let j in this.sales[i].articles){
						this.total += this.sales[i].articles[j].price;
						this.sales[i].total += this.sales[i].articles[j].price;
						this.ventas_cont ++;
					}
				}
			})
			.catch( error => {
				console.log(error.response);
			})
		},
		getSalesAfternoon: function(){
			axios.get('sales/today/afternoon')
			.then( response => {
				this.sales = response.data;
				this.total = 0;
				this.ventas_cont = 0;
				for(let i in this.sales){
					this.sales[i].total = 0;
					for(let j in this.sales[i].articles){
						this.total += this.sales[i].articles[j].price;
						this.sales[i].total += this.sales[i].articles[j].price;
						this.ventas_cont ++;
					}
				}
			})
			.catch( error => {
				console.log(error.response);
			})
		}
	}
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\negocio\resources\views/main/resumen-ventas-hoy.blade.php ENDPATH**/ ?>