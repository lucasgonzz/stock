<?php $__env->startSection('content'); ?>
	<div id="resumen-ventas" class="m-t-30">
		<div class="row justify-content-center">
			<div class="col col-lg-8">
				<ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist">
					<li class="nav-item m-l-0">
						<a class="nav-link active" id="pills-all-tab" data-toggle="pill" href="#nav-hoy" role="tab" aria-controls="pills-home" aria-selected="true" @click="getSales">Todas</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="pills-morning-tab" data-toggle="pill" href="#nav-hoy" role="tab" aria-controls="pills-profile" aria-selected="false" @click="getSalesMorning">De mañana</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="pills-afternoon-tab" data-toggle="pill" href="#nav-hoy" role="tab" aria-controls="pills-contact" aria-selected="false" @click="getSalesAfternoon">De tarde</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#nav-desde-una-fecha" role="tab" aria-controls="pills-contact" aria-selected="false">Desde una fecha</a>
					</li>
				</ul>
			</div>
		</div>
		<?php echo $__env->make('includes.resumen-ventas-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- <hr style="background-color: #A8A8A8"> -->
		<?php echo $__env->make('includes.resumen-ventas-show-sales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>		
		<?php echo $__env->make('modals.lastSales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	new Vue({
	el: "#resumen-ventas",
	created: function(){
		this.getSales();
	},
	data: {
		sales: [],
		mostrar: 'ventas-hoy',
		total: 0,
		lastSales: [],
		mostrar: 0,
		ventas_cont: 0,

		// Desde una fecha
		desde: '',
		hasta: '',
		busqueda_por_fecha: false,
		ultima_fecha: '',

		// Mostrar ventas anteriores
		sale: {},
		article: {},
	},
	methods: {
		deleteSale: function(sale){
			axios.delete('sales/' + sale.id)
			.then( response => {
				this.getSales();
				toastr.success('Se elimino la venta');
			})
			.catch( error => {
				console.log(error.response);
			})
		},
		deleteArticle: function(sale_id, sale_articles, article) {
			var articles_ids = [];
			for(let i in sale_articles) {
				articles_ids.push(sale_articles[i].id);
			}
			console.log('primero: ');
			console.log(articles_ids);

			let index = articles_ids.indexOf(article.id);
			articles_ids.splice(index, 1);
			console.log('despues: ');
			console.log(articles_ids);

			axios.post('sales/delete-article', {
				article_id	    : article.id,
				sale_id			: sale_id,
				articles_ids	: articles_ids,
 			})
			.then( response => {
				console.log('respuesta: ');
				console.log(response.data);
				this.getSales();
				toastr.success('Se elimino el articulo ' + article.name + ' de la venta');
			})
			.catch( error => {
				console.log(error.response);
			})
		},
		showLastSales: function(article){
			this.article = article;
			this.lastSales = article.sales;
			$('#last-sales').modal('show');
		},
		salesFrom: function() {
			axios.post('sales/from-date', {
				desde : this.desde,
				hasta : this.hasta,
			})
			.then( response => {
				console.log(response.data);
				this.sales = response.data;
				this.calcular_total_cantidad_ventas(this.sales);

				// Se actualiza busqueda-por-fecha para que se muestren
				// los dias (columnas grises) en la tabla
				this.busqueda_por_fecha = true;
			}).catch( error => {
				console.log(error.response);
			});
		},
		getSales: function(){
			axios.get('sales/today')
			.then( response => { 
				console.log(response.data);
				this.sales = response.data;
				this.calcular_total_cantidad_ventas(this.sales);
			})
			.catch( error => {
				console.log(error.response);
				location.reload();
			})
		},
		getSalesMorning: function(){
			axios.get('sales/morning')
			.then( response => {
				this.sales = response.data;
				this.calcular_total_cantidad_ventas(this.sales);
			})
			.catch( error => {
				console.log(error.response);
			})
		},
		getSalesAfternoon: function(){
			axios.get('sales/afternoon')
			.then( response => {
				console.log(response.data);
				this.sales = response.data;
				this.calcular_total_cantidad_ventas(this.sales);
			})
			.catch( error => {
				console.log(error.response);
			})
		},
		calcular_total_cantidad_ventas: function(sales) {
			this.total = 0;
			this.ventas_cont = 0;
			for(let i in sales){
				for(let j in sales[i].articles){
					this.total += sales[i].articles[j].price;
					this.ventas_cont ++;
				}
			}
		}
	}
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\negocio\resources\views/main/resumen-ventas.blade.php ENDPATH**/ ?>