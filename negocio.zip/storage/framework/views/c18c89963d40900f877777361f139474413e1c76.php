<nav class="navbar navbar-expand-lg bg-dark">
	<button class="navbar-toggler btn-menu" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
		<i class="fas fa-bars fa-lg"></i>
	</button>
	<div class="collapse navbar-collapse" id="navbarTogglerDemo01">
		<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
			<li class="nav-item active">
				<a class="nav-link <?php echo e(active('venta')); ?>" href="<?php echo e(route('venta')); ?>"><i class="fas fa-tags fa-xs m-r-5"></i>Venta</a>
			</li>
			<li class="nav-item active">
				<a class="nav-link <?php echo e(active('ingresar')); ?>" href="<?php echo e(route('ingresar')); ?>"><i class="fas fa-external-link-alt fa-xs m-r-5"></i>Ingresar</a>
			</li>
			<li class="nav-item active">
				<a class="nav-link <?php echo e(active('lista-precios')); ?>" href="<?php echo e(route('lista-precios')); ?>"><i class="fas fa-list-ol m-r-5"></i>Lista de precios</a>
			</li>
			<li class="nav-item active">
				<a class="nav-link <?php echo e(active('resumen-ventas')); ?>" href="<?php echo e(route('resumen-ventas')); ?>"><i class="fas fa-key m-r-5 fa-xs"></i>Resumen de ventas</a>
			</li>
			<li class="nav-item active">
				<a class="nav-link <?php echo e(active('codigos-de-barras')); ?>" href="<?php echo e(route('codigos-de-barras')); ?>"><i class="fas fa-key m-r-5 fa-xs"></i>Codigos de barras</a>
			</li>
			<li class="nav-item active">
				<form method="POST" action="<?php echo e(route('logout')); ?>">
					<?php echo e(csrf_field()); ?>

					<button class="nav-link btn-logout" type="submit"><i class="fas fa-sign-out-alt m-r-5"></i>Salir</button>
				</form>
			</li>
		</ul>
	</div>
</nav><?php /**PATH C:\wamp64\www\negocio\resources\views/app/nav.blade.php ENDPATH**/ ?>