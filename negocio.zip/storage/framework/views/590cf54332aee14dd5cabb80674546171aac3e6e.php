<div class="modal fade" id="add-provider" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Nuevo Proovedor</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="text" name="" class="form-control" v-model="provider" placeholder="Nombre del proovedor">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="button" class="btn btn-primary" v-on:click="saveProvider">Guardar</button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\wamp64\www\negocio\resources\views/modals/addProvider.blade.php ENDPATH**/ ?>