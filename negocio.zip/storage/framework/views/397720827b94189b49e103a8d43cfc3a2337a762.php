<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Control de Stock</title>

	<!-- app.css -->
	<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
	
	<!-- toastr.css -->
	<link href="<?php echo e(asset('css/toastr.css')); ?>" rel="stylesheet">
</head>
<body>
	<?php echo $__env->make('app.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('content'); ?>
	<script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script type="text/javascript" src="https://kit.fontawesome.com/6a9cf36c74.js"></script>
	<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\wamp64\www\negocio\resources\views/app/app.blade.php ENDPATH**/ ?>